# Pixel Vault — GitHub auto-publish starter

This package contains the deployable Pixel Vault site plus a GitHub Actions workflow. After the one-time setup, you can publish from the Actions tab, and commits to `main` will also deploy automatically.

## One-time setup

1. Create a **private** GitHub repository named `pixel-vault-site` (or another name) with an empty README option **unchecked** / no starter files.
2. Upload the contents of this ZIP to the repository root, preserving `index.html`, `assets/`, `games/`, and `_redirects`. Also upload `.github/workflows/publish-bunny.yml` from this package.
3. In the repository, open **Settings → Secrets and variables → Actions → New repository secret**.
4. Name the secret exactly `BUNNY_STORAGE_PASSWORD` and paste the **Storage Zone password** for `pixelvault08`. Do not put the password in code or chat.
5. Open **Actions → Publish Pixel Vault to Bunny → Run workflow**. The first run should upload the files to the existing Bunny Storage Zone in New York.
6. Afterward, edit files in GitHub and commit to `main`, or use the Run workflow button to republish.

## Safety notes

- This workflow uploads files to the existing zone `pixelvault08` in `ny.storage.bunnycdn.com`.
- It does not delete remote files, so old unused files may remain. It overwrites same-path files.
- Never add your Bunny password to a tracked file. If you accidentally expose it, rotate it in Bunny immediately.
- This automates publishing; it does not itself repair gameplay or guarantee every external service works.
